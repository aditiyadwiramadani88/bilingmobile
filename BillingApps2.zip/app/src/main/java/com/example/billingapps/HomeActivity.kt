package com.example.billingapps

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.billingapps.ui.theme.BillingAppsTheme

class HomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BillingAppsTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FocusGuardScreen()
                }
            }
        }
    }
}

@Composable
fun FocusGuardScreen() {
    val context = LocalContext.current
    var isAccessibilityEnabled by remember { mutableStateOf(isAccessibilityServiceEnabled(context)) }
    var blockedAppsCount by remember { mutableStateOf(BlockedAppsManager.getBlockedApps(context).size) }
    var isLockingActive by remember { mutableStateOf(BlockedAppsManager.getLockStatus(context)) }


    // Launcher untuk mendapatkan hasil dari SelectBlockAppActivity
    val appSelectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        // Saat kembali dari layar pemilihan, perbarui semua status
        blockedAppsCount = BlockedAppsManager.getBlockedApps(context).size
        isLockingActive = BlockedAppsManager.getLockStatus(context)
    }

    // Memeriksa status saat kembali ke aplikasi
    DisposableEffect(Unit) {
        val activity = context as ComponentActivity
        val lifecycleObserver = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                isAccessibilityEnabled = isAccessibilityServiceEnabled(context)
                blockedAppsCount = BlockedAppsManager.getBlockedApps(context).size
                isLockingActive = BlockedAppsManager.getLockStatus(context)
            }
        }
        activity.lifecycle.addObserver(lifecycleObserver)
        onDispose {
            activity.lifecycle.removeObserver(lifecycleObserver)
        }
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF0F2F5))
            .padding(24.dp)
    ) {
        // Header
        Text(text = "FocusGuard", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Text(text = "Mode: Aktif", fontSize = 16.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(24.dp))

        // Status Aksesibilitas
        AccessibilityStatus(
            isEnabled = isAccessibilityEnabled,
            onActivateClick = {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                context.startActivity(intent)
            }
        )
        Spacer(modifier = Modifier.height(24.dp))

        // Kartu Opsi: Set Block Apps
        OptionCard(
            modifier = Modifier.clickable {
                val intent = Intent(context, SelectBlockAppActivity::class.java)
                appSelectionLauncher.launch(intent)
            },
            icon = Icons.Default.CheckCircle,
            title = "Set Block Apps",
            subtitle = "$blockedAppsCount Apps Blocked",
            iconColor = Color(0xFF6A5AE0),
            trailingContent = {
                if (blockedAppsCount > 0) {
                    Text(
                        text = "Clear",
                        color = Color.Gray,
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .clickable {
                                BlockedAppsManager.saveBlockedApps(context, emptySet())
                                blockedAppsCount = 0
                            }
                    )
                }
            }
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Kartu Opsi: Set Whitelist Apps
        OptionCard(
            icon = Icons.Default.Check,
            title = "Set Whitelist Apps",
            subtitle = "Pilih aplikasi yang diizinkan",
            iconColor = Color(0xFF6A5AE0)
        )

        Spacer(modifier = Modifier.weight(1f))

        // Tombol Lock Apps menjadi Switch
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Lock Apps", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
            Switch(
                checked = isLockingActive,
                onCheckedChange = {
                    isLockingActive = it
                    BlockedAppsManager.saveLockStatus(context, it)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(0xFF6A5AE0)
                )
            )
        }
    }
}

@Composable
fun OptionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconColor: Color,
    trailingContent: @Composable (() -> Unit)? = null
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFEDEDF4))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(32.dp),
                tint = iconColor
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                Text(text = subtitle, fontSize = 14.sp, color = Color.Gray)
            }
            trailingContent?.invoke()
        }
    }
}


@Composable
fun AccessibilityStatus(isEnabled: Boolean, onActivateClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) Color(0xFFE6F9F0) else Color(0xFFFFF4E5)
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Status Aksesibilitas",
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
                Text(
                    text = if (isEnabled) "Aktif" else "Tidak Aktif",
                    color = if (isEnabled) Color(0xFF00875A) else Color(0xFFE67E22)
                )
            }
            if (!isEnabled) {
                Button(
                    onClick = onActivateClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A5AE0))
                ) {
                    Text("Aktifkan")
                }
            }
        }
    }
}


private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val service = "${context.packageName}/${FocusGuardAccessibilityService::class.java.canonicalName}"
    val settingValue = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    )
    return settingValue?.contains(service) ?: false
}

@Preview(showBackground = true)
@Composable
fun DefaultPreviewHome() {
    BillingAppsTheme {
        FocusGuardScreen()
    }
}

