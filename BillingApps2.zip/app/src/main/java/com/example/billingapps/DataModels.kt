package com.example.billingapps
import com.google.gson.annotations.SerializedName

// Response untuk aktivasi perangkat
data class DeviceActivationResponse(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("data")
    val data: DeviceData?,
    @SerializedName("message")
    val message: String?
)

data class DeviceData(
    @SerializedName("id")
    val id: Int,

    @SerializedName("device_id")
    val deviceId: String,

    @SerializedName("name")
    val name: String,

    @SerializedName("status")
    val status: String
)

// Model baru untuk Login dengan PIN
data class PinLoginRequest(
    @SerializedName("pin")
    val pin: String
)

data class PinLoginResponse(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("message")
    val message: String
)
