package com.example.billingapps

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val PREFS_NAME = "BillingAppPrefs"
private const val KEY_DEVICE_ID = "deviceId"

@SuppressLint("CustomSplashScreen")
class SplashActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // UI Sederhana untuk Splash Screen
        setContent {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Billing Apps")
            }
        }

        CoroutineScope(Dispatchers.Main).launch {
            // Beri jeda agar splash screen terlihat
            delay(1500)

            val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val deviceId = sharedPreferences.getString(KEY_DEVICE_ID, null)

            // Tentukan activity selanjutnya berdasarkan status aktivasi
            val nextActivity = if (deviceId != null) {
                PinActivity::class.java
            } else {
                ActivationActivity::class.java
            }

            startActivity(Intent(this@SplashActivity, nextActivity))
            // Tutup SplashActivity agar tidak bisa kembali
            finish()
        }
    }
}
