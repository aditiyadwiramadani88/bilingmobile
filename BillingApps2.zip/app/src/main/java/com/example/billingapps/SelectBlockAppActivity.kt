package com.example.billingapps

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.billingapps.ui.theme.BillingAppsTheme
import com.google.accompanist.drawablepainter.rememberDrawablePainter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Data class untuk menampung informasi aplikasi
data class AppInfo(
    val name: String,
    val packageName: String,
    val icon: Drawable
)

// Sealed interface untuk merepresentasikan state UI
sealed interface AppListUiState {
    object Loading : AppListUiState
    data class Success(val apps: List<AppInfo>) : AppListUiState
}


class SelectBlockAppActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BillingAppsTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BlockingAppsScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockingAppsScreen() {
    val context = LocalContext.current
    // State untuk menampung status UI (Loading atau Success)
    var uiState by remember { mutableStateOf<AppListUiState>(AppListUiState.Loading) }

    // Coroutine untuk memuat daftar aplikasi di background
    LaunchedEffect(Unit) {
        launch(Dispatchers.IO) {
            val applist = getInstalledApps(context)
            // Setelah data didapat, update state di main thread
            withContext(Dispatchers.Main) {
                uiState = AppListUiState.Success(applist)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FocusGuard", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black
                )
            )
        },
        containerColor = Color.White
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // Tampilkan UI berdasarkan state saat ini
            when (val state = uiState) {
                is AppListUiState.Loading -> {
                    // Tampilkan loading indicator di tengah layar
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                is AppListUiState.Success -> {
                    // Jika berhasil, tampilkan konten utama
                    AppSelectionContent(allApps = state.apps)
                }
            }
        }
    }
}

@Composable
fun ColumnScope.AppSelectionContent(allApps: List<AppInfo>) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedApps by remember { mutableStateOf(BlockedAppsManager.getBlockedApps(context)) }
    var isLockingActive by remember { mutableStateOf(BlockedAppsManager.getLockStatus(context)) }

    val areAllSelected = allApps.isNotEmpty() && selectedApps.size == allApps.size
    val selectAllText = if (areAllSelected) "Deselect All" else "Select All"

    val filteredApps = if (searchQuery.isEmpty()) {
        allApps
    } else {
        allApps.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    // Header
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Blocking Apps", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            text = selectAllText,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable {
                val newSelectedApps = if (areAllSelected) {
                    emptySet()
                } else {
                    allApps.map { it.packageName }.toSet()
                }
                selectedApps = newSelectedApps
                BlockedAppsManager.saveBlockedApps(context, newSelectedApps)
            }
        )
    }
    Spacer(modifier = Modifier.height(16.dp))

    // Search Bar
    OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Search apps") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFF6A5AE0),
            unfocusedBorderColor = Color.Gray.copy(alpha = 0.4f)
        )
    )
    Spacer(modifier = Modifier.height(16.dp))

    // Daftar Aplikasi
    AppList(
        apps = filteredApps,
        selectedApps = selectedApps,
        onAppSelected = { appPackage, isSelected ->
            val newSelectedApps = selectedApps.toMutableSet()
            if (isSelected) {
                newSelectedApps.add(appPackage)
            } else {
                newSelectedApps.remove(appPackage)
            }
            selectedApps = newSelectedApps
            BlockedAppsManager.saveBlockedApps(context, newSelectedApps)
        }
    )

    // Footer dengan tombol Lock Apps
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Lock Apps", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Switch(
            checked = isLockingActive,
            onCheckedChange = {
                isLockingActive = it
                BlockedAppsManager.saveLockStatus(context, it)
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF6A5AE0)
            )
        )
    }
}


@Composable
fun ColumnScope.AppList(
    apps: List<AppInfo>,
    selectedApps: Set<String>,
    onAppSelected: (String, Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier.weight(1f)
    ) {
        items(apps, key = { it.packageName }) { app ->
            AppListItem(
                appInfo = app,
                isSelected = selectedApps.contains(app.packageName),
                onCheckedChange = { isSelected ->
                    onAppSelected(app.packageName, isSelected)
                }
            )
        }
    }
}

@Composable
fun AppListItem(
    appInfo: AppInfo,
    isSelected: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!isSelected) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = rememberDrawablePainter(drawable = appInfo.icon),
            contentDescription = "${appInfo.name} icon",
            modifier = Modifier.size(40.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = appInfo.name,
            modifier = Modifier.weight(1f)
        )
        Checkbox(
            checked = isSelected,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = Color(0xFF6A5AE0)
            )
        )
    }
}

// Fungsi untuk memuat aplikasi, sekarang di luar composable
private fun getInstalledApps(context: Context): List<AppInfo> {
    val packageManager: PackageManager = context.packageManager
    val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
    val appList = mutableListOf<AppInfo>()

    for (app in apps) {
        // Filter untuk hanya menampilkan aplikasi yang bisa dibuka dan bukan aplikasi kita sendiri
        if (packageManager.getLaunchIntentForPackage(app.packageName) != null && app.packageName != context.packageName) {
            val appInfo = AppInfo(
                name = packageManager.getApplicationLabel(app).toString(),
                packageName = app.packageName,
                icon = packageManager.getApplicationIcon(app)
            )
            appList.add(appInfo)
        }
    }
    // Mengurutkan daftar berdasarkan nama aplikasi
    return appList.sortedBy { it.name.lowercase() }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreviewSelectBlockApp() {
    BillingAppsTheme {
        // Karena loading butuh coroutine, preview hanya akan menampilkan box kosong.
        // Untuk preview UI, bisa panggil AppSelectionContent langsung dengan data dummy.
        Box(modifier = Modifier
            .fillMaxSize()
            .background(Color.White))
    }
}

