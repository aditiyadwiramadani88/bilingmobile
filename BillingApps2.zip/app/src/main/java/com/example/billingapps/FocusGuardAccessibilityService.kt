package com.example.billingapps

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class FocusGuardAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Hanya proses event ketika ada perubahan jendela di layar
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return

            // Jangan blokir aplikasi kita sendiri atau launcher bawaan HP
            if (packageName == applicationContext.packageName || isLauncher(packageName)) {
                return
            }

            // Ambil status kunci dan daftar aplikasi yang diblokir dari SharedPreferences
            val isLockingActive = BlockedAppsManager.getLockStatus(this)
            val blockedApps = BlockedAppsManager.getBlockedApps(this)

            // Cek apakah mode blokir aktif DAN aplikasi yang sedang dibuka ada di dalam daftar
            if (isLockingActive && blockedApps.contains(packageName)) {
                // --- LOGIKA BARU: LANGSUNG TAMPILKAN LAYAR BLOKIR ---
                // Menghapus logika "kembali ke home" dan delay.
                // Layar pemblokiran akan langsung muncul di atas aplikasi yang dibuka.
                val intent = Intent(this, BlockScreenActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
        }
    }

    // Fungsi untuk mengecek apakah sebuah package adalah launcher
    private fun isLauncher(packageName: String): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_HOME) }
        val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolveInfo != null && resolveInfo.activityInfo.packageName == packageName
    }


    override fun onInterrupt() {
        Log.d("FocusGuardService", "Service interrupted")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d("FocusGuardService", "Service connected")
    }
}

