package com.example.billingapps

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    @GET("api/devices/{deviceId}")
    suspend fun activateDevice(
        @Path("deviceId") deviceId: String
    ): Response<DeviceActivationResponse>

    @POST("api/login/{deviceId}")
    suspend fun loginWithPin(
        @Path("deviceId") deviceId: String,
        @Body request: PinLoginRequest
    ): Response<PinLoginResponse>
}
