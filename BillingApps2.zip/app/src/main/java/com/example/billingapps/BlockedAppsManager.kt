package com.example.billingapps

import android.content.Context
import android.content.SharedPreferences

object BlockedAppsManager {

    private const val PREFS_NAME = "FocusGuardPrefs"
    private const val KEY_BLOCKED_APPS = "blocked_apps"
    private const val KEY_LOCK_STATUS = "lock_status"

    private fun getPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun saveBlockedApps(context: Context, apps: Set<String>) {
        val editor = getPreferences(context).edit()
        editor.putStringSet(KEY_BLOCKED_APPS, apps)
        editor.apply()
    }

    fun getBlockedApps(context: Context): Set<String> {
        return getPreferences(context).getStringSet(KEY_BLOCKED_APPS, emptySet()) ?: emptySet()
    }

    fun saveLockStatus(context: Context, isActive: Boolean) {
        val editor = getPreferences(context).edit()
        editor.putBoolean(KEY_LOCK_STATUS, isActive)
        editor.apply()
    }

    fun getLockStatus(context: Context): Boolean {
        return getPreferences(context).getBoolean(KEY_LOCK_STATUS, false)
    }
}
