package com.example.billingapps.services
//import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.work.OneTimeWorkRequestBuilder

import androidx.work.WorkManager
import com.pusher.client.Pusher
import com.pusher.client.PusherOptions
import com.pusher.client.connection.ConnectionEventListener
import com.pusher.client.connection.ConnectionState
import com.pusher.client.connection.ConnectionStateChange

class PusherService() {

//
//    private var pusher: Pusher? = null
//
//    companion object {
//        const val TAG = "PusherService"
//        // TODO: Ganti dengan kredensial Pusher Anda dari backend
//        const val PUSHER_APP_KEY = "ganti_dengan_app_key_anda"
//        const val PUSHER_APP_CLUSTER = "ganti_dengan_cluster_anda"
//        const val EVENT_NAME = ".device.action"
//
//        // Konstanta untuk SharedPreferences, disamakan dengan SplashActivity
//        private const val PREFS_NAME = "BillingAppPrefs"
//        private const val KEY_DEVICE_ID = "deviceId"
//    }
//
//    override fun onCreate() {
//        super.onCreate()
//        Log.d(TAG, "Service creating...")
//
//        // Ambil deviceId dari SharedPreferences
//        val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
//        val deviceId = sharedPreferences.getString(KEY_DEVICE_ID, null)
//
//        if (deviceId == null) {
//            Log.e(TAG, "Device ID not found in SharedPreferences. Stopping service.")
//            stopSelf() // Hentikan service jika tidak ada deviceId
//            return
//        }
//
//        Log.d(TAG, "Found Device ID: $deviceId. Initializing Pusher.")
//
//        val options = PusherOptions().setCluster(PUSHER_APP_CLUSTER)
//        pusher = Pusher(PUSHER_APP_KEY, options)
//
//        pusher?.connect(object : ConnectionEventListener {
//            override fun onConnectionStateChange(change: ConnectionStateChange) {
//                Log.i(TAG, "State changed from ${change.previousState} to ${change.currentState}")
//            }
//
//            override fun onError(message: String, code: String?, e: Exception?) {
//                Log.e(TAG, "Connection error: $message, code: $code, exception: $e")
//            }
//        }, ConnectionState.ALL)
//
//        // Gunakan deviceId untuk subscribe ke channel yang dinamis
//        val channelName = "private-device.$deviceId"
//        Log.d(TAG, "Subscribing to channel: $channelName")
//        val channel = pusher?.subscribePrivate(channelName)
//
//        channel?.bind(EVENT_NAME) { event ->
//            Log.i(TAG, "Received event with data: ${event.data}")
//            // Ketika event diterima, picu Worker untuk cek API
//            triggerDeviceStatusCheck()
//        }
//    }
//
//    private fun triggerDeviceStatusCheck() {
//        Log.d(TAG, "Triggering DeviceStatusWorker.")
//        val workRequest = OneTimeWorkRequestBuilder<DeviceStatusWorker>().build()
//        WorkManager.getInstance(applicationContext).enqueue(workRequest)
//    }
//
//
//    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
//        Log.d(TAG, "Service started.")
//        return START_STICKY
//    }
//
//    override fun onDestroy() {
//        super.onDestroy()
//        Log.d(TAG, "Service destroying...")
//        pusher?.disconnect()
//    }
//
//    override fun onBind(intent: Intent?): IBinder? {
//        return null
//    }
}


